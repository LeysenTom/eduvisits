﻿using API_app.Models;
using API_app.ViewModels;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net.Http;

namespace API_app.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private const string APIkey = "API-Key";
        private string _key;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _key = configuration[APIkey];
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Display(adress adres)
        {
            Console.WriteLine(adres.link);
            if (!ModelState.IsValid)
            {
                Console.WriteLine("invalid");
                return RedirectToAction(nameof(NoData));
            }
            if (string.IsNullOrWhiteSpace(adres.link))
            {
                Console.WriteLine("nolink");
                return RedirectToAction(nameof(NoData));
            }
            List<ApiViewModel> vm = new List<ApiViewModel>();

            ApiViewModel? week1 = await ApiCall(0, adres.link);
            ApiViewModel? week2 = await ApiCall(1, adres.link);
            if (week1 == null || week2 == null)
            {
                return RedirectToAction(nameof(NoData));
            }

            vm.Add(week1);
            vm.Add(week2);

            return View(vm);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult NoData()
        {
            return View();
        }

        public async Task<ApiViewModel?> ApiCall(int weekdiff, string startadress)
        {
            // aanmaken VM
            ApiViewModel? vm = new ApiViewModel();

            //var
            string APIAdress = startadress + "/api/afwezigheid/";
            List<APIReturnValues>? returnValues = new List<APIReturnValues>();
            List<int> dagen = new List<int>() { 0, 1, 2, 3, 4 }; //(maandag==0 tot vrijdag == 4)
            List<int> uren = new List<int>() { 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 }; //(8 tot 20 uur)

            //request
            using (HttpClient HttpClient = new HttpClient())
            {
                try
                {
                    HttpClient.DefaultRequestHeaders.Add("X-API-KEY", _key);
                    var APIReturnValue = await HttpClient.GetAsync(APIAdress + weekdiff.ToString());
                    string APIReturnString = await APIReturnValue.Content.ReadAsStringAsync();
                    returnValues = JsonConvert.DeserializeObject<List<APIReturnValues>>(APIReturnString);
                }
                catch
                {
                    Console.WriteLine("Request Failed");
                    vm = null;
                    return vm;
                }
            }

            if (returnValues == null)
            {
                vm = null;
                return vm;
            }

            //week dag 1 correct zetten; 0 = zondag, 1 = maandag, 6 = zaterdag => naar 1/maandag zetten
            DateTime date = DateTime.Now.AddDays(weekdiff * 7);
            if (((int)date.DayOfWeek) == 0)
            {
                date = date.AddDays(-6);
            }
            else if (((int)date.DayOfWeek) != 1)
            {
                date = date.AddDays(-(((int)date.DayOfWeek) - 1));
            }
            Console.WriteLine(date.ToString("d MMMM yyyy H:mm"));
            //reset date time naar time 0:00
            TimeSpan time = new TimeSpan(0, 0, 0);
            date = date.Date + time;
            Console.WriteLine(date.ToString("d MMMM yyyy H:mm"));
            Console.WriteLine(((int)date.DayOfWeek));

            //grid dag * uur => elk slot invullen met afwezige op dat moment [0].[0] == dag 1 op uur 1
            vm.TableHead.Add("rooster");
            foreach (int item in dagen)
            {
                DateTime loopDate = date.AddDays(item);
                vm.TableHead.Add(loopDate.ToString("d/MM"));
                List<List<Afwezige>> LijstHuidigeDag = new List<List<Afwezige>>();

                foreach (int uur in uren)
                {
                    TimeSpan loopTime = new TimeSpan(uur, 0, 0);
                    loopDate = loopDate.Date + loopTime;
                    TimeSpan loopTimeHourEnd = new TimeSpan(uur + 1, 0, 0);
                    DateTime loopDateHourEnd = loopDate.Date + loopTimeHourEnd;
                    List<Afwezige> LijstUur = new List<Afwezige>();
                    foreach (APIReturnValues ApiAfwezige in returnValues)
                    {
                        if (ApiAfwezige.StartDatum < loopDateHourEnd && loopDate < ApiAfwezige.EindDatum)
                        {
                            Afwezige afwezige = new Afwezige();
                            afwezige.GebruikerNaam = ApiAfwezige.GebruikerNaam;
                            afwezige.GebruikerRol = ApiAfwezige.GebruikerRol;
                            if (afwezige.GebruikerRol == "Leerkracht")
                            {
                                afwezige.color = "btn-primary";
                            }
                            else
                            {
                                afwezige.color = "btn-danger";
                            }

                            LijstUur.Add(afwezige);
                        }
                    }
                    LijstHuidigeDag.Add(LijstUur);
                }

                vm.TableBody.Add(LijstHuidigeDag);
            }
            //uren toevoegen aan vm
            foreach (int uur in uren)
            {
                TimeSpan time2 = new TimeSpan(uur, 0, 0);
                date = date.Date + time2;
                vm.TableRowHead.Add(date.ToString("HH:mm"));
            }
            return vm;
        }
    }
}