﻿namespace API_app.Models
{
    public class Afwezige
    {
        public string GebruikerNaam { get; set; }
        public string GebruikerRol { get; set; }

        public string color { get; set; }
    }
}