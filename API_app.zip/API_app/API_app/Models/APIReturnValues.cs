﻿namespace API_app.Models
{
    public class APIReturnValues
    {
        public string GebruikerNaam { get; set; }
        public string GebruikerRol { get; set; }

        public DateTime StartDatum { get; set; }

        public DateTime EindDatum { get; set; }
    }
}