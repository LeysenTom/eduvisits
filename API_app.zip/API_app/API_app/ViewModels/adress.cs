﻿namespace API_app.ViewModels
{
    public class adress
    {
        public string link { get; set; }
    }
}