﻿using API_app.Models;

namespace API_app.ViewModels
{
    public class ApiViewModel
    {
        public List<string> TableHead { get; set; }
        public List<string> TableRowHead { get; set; }
        public List<List<List<Afwezige>>> TableBody { get; set; }

        public ApiViewModel()
        {
            TableHead = new List<string>();
            TableRowHead = new List<string>();
            TableBody = new List<List<List<Afwezige>>>();
        }
    }
}